

<?php $__env->startSection('title'); ?>
    Data | Anggota
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
  Data Anggota
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formcari'); ?>
<form action="<?php echo e(route('anggota.index')); ?>" method="get">
  <div class="input-group">
    <span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span>
    <input type="search" name="search" class="form-control" placeholder="Type here...">
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('anggota'); ?>
  "nav-link active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('normal'); ?>
  "nav-link"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
    <div class="col-12">
      <div class="card mb-4">
        <div class="card-header pb-0 d-flex">
          <h6 class="flex-grow-1"><?php echo $__env->yieldContent('page'); ?></h6>
          <a href="<?php echo e(route('anggota.create')); ?>" class="btn btn-primary d-flex"  style="margin-left: 8px">
            <i class="material-icons">save</i>
            <p style="margin: 0 0 0 5px;">Add</p>
          </a>
          <a href="<?php echo e('/anggota-report'); ?>" class="btn btn-primary d-flex"  style="margin-left: 8px">
            <i class="material-icons">download</i>
            <p style="margin: 0 0 0 5px;">Cetak</p>
          </a>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-center">No.</th>
                  <th class="text-center">NIK</th>
                  <th class="text-center">Nama</th>
                  <th class="text-center">Jenis Kelamin</th>
                  <th class="text-center">Tgl lahir</th>
                  <th class="text-center">Alamat</th>
                  <th class="text-center">No Telepon</th>
                  <th class="text-center">Email</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td class="text-center"><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($agg->nik); ?></td>
                      <td><?php echo e($agg->nama); ?></td>
                      <td><?php echo e($agg->jenis_kelamin); ?></td>
                      <td><?php echo e($agg->tgl_lahir); ?></td>
                      <td><?php echo e($agg->alamat); ?></td>
                      <td><?php echo e($agg->email); ?></td>
                      <td><?php echo e($agg->no_tlp); ?></td>
                      <td>
                        <a class='btn btn-success btn-sm' href="<?php echo e(route('anggota.edit',$agg->id_member)); ?>">Edit</a>
                        <a class='btn btn-danger btn-sm' href="/anggota/hapus/<?php echo e($agg->id_member); ?>">Hapus</a>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="9" align="center">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo e($anggota->links()); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\SI-Koperasi\resources\views/anggota/anggota.blade.php ENDPATH**/ ?>