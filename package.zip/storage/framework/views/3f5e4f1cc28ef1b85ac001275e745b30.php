

<?php $__env->startSection('title'); ?>
    Data | Simpanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
  Data Simpanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('simpanan'); ?>
  "nav-link active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('normal'); ?>
  "nav-link"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
    <div class="col-12">
      <div class="card mb-4">
        <div class="card-header pb-0 d-flex">
          <h6 class="flex-grow-1"><?php echo $__env->yieldContent('page'); ?></h6>
          <a href="<?php echo e('/simpanan-report'); ?>" class="btn btn-primary d-flex"  style="margin-left: 8px">
            <i class="material-icons">download</i>
            <p style="margin: 0 0 0 5px;">Cetak</p>
          </a>
        </div>
        <div class="p-4">
          <h6><strong>Nama Anggota :</strong> <?php echo e($namaAnggota); ?></h6>
          <h6><strong>Jenis Simpanan :</strong> Simpanan <?php echo e($carijenis); ?></h6>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                  <tr>
                      <th class="text-center">No.</th>
                      <th class="text-center">Tanggal Simpan</th>
                      <th class="text-center">Jumlah Simpanan</th>
                      
                  </tr>
              </thead>
              <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $filteredSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $simp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                          <td class="text-center"><?php echo e($loop->iteration); ?></td>
                          <td class="text-center"><?php echo e($simp->tgl_simpan); ?></td>
                          <td class="text-center"><?php echo e($simp->jumlah_simpanan); ?></td>
                          
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                          <td colspan="6" align="center">Tidak ada data</td>
                      </tr>
                  <?php endif; ?>
              </tbody>
          </table>     
          <h6 class="flex-grow-1 float-end p-4">Total Simpanan : Rp.<?php echo e($total); ?></h6>     
        </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo e($filteredSimpanan->links()); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\SI-Koperasi\resources\views/simpanan/simpanan.blade.php ENDPATH**/ ?>