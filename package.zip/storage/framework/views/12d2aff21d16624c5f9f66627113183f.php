

<?php $__env->startSection('title'); ?>
    Data | Pinjaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
  Data Pinjaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formcari'); ?>
<form action="<?php echo e(route('pinjaman.index')); ?>" method="get">
  <div class="input-group">
    <span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span>
    <input type="search" name="search" class="form-control" placeholder="Type here...">
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pinjaman'); ?>
  "nav-link active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('normal'); ?>
  "nav-link"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
    <div class="col-12">
      <div class="card mb-4">
        <div class="card-header pb-0 d-flex">
          <h6 class="flex-grow-1"><?php echo $__env->yieldContent('page'); ?></h6>
          <a href="<?php echo e('/pinjaman-report'); ?>" class="btn btn-primary d-flex"  style="margin-left: 8px">
            <i class="material-icons">download</i>
            <p style="margin: 0 0 0 5px;">Cetak</p>
          </a>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                  <tr>
                      <th class="text-center">No.</th>
                      <th class="text-center">Nama</th>
                      <th class="text-center">Jumlah Pinjaman</th>
                      <th class="text-center">Tanggal Pinjam</th>
                      <th class="text-center">Tanggal Jatuh Tempo</th>
                      <th class="text-center">Tenor</th>
                      <th class="text-center">Jumlah Bayar</th>
                      <th class="text-center">Status Pinjaman</th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                          <td class="text-center"><?php echo e($loop->iteration); ?></td>
                          <td class="text-center"><?php echo e($pjm->anggota->nama); ?></td>
                          <td class="text-center"><?php echo e($pjm->jumlah_pinjaman); ?></td>
                          <td class="text-center"><?php echo e($pjm->tgl_pinjam); ?></td>
                          <td class="text-center"><?php echo e($pjm->tgl_jatuh_tempo); ?></td>
                          <td class="text-center"><?php echo e($pjm->tenor); ?></td>
                          <td class="text-center"><?php echo e($pjm->jumlah_bayar); ?></td>
                          <!-- Kondisi untuk status pinjaman -->
                          <?php if($pjm->status_pinjaman == "lunas"): ?>
                            <td class="text-center">
                                <a class="btn btn-success btn-sm">
                                    <?php echo e($pjm->status_pinjaman); ?>

                                </a>
                            </td>
                          <?php else: ?>
                            <td class="text-center">
                              <a class="btn btn-danger btn-sm" href="<?php echo e(route('pinjaman.edit', [$pjm->id_pinjaman,$pjm->nama])); ?>">
                                  <?php echo e($pjm->status_pinjaman); ?>

                              </a>
                            </td>
                          <?php endif; ?>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                          <td colspan="8" align="center">Tidak ada data</td>
                      </tr>
                  <?php endif; ?>
              </tbody>
          </table>                  
        </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo e($pinjaman->links()); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\SI-Koperasi\resources\views/pinjaman/pinjaman.blade.php ENDPATH**/ ?>