

<?php $__env->startSection('title'); ?>
    Data | Simpanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
  Pilih Data Simpanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('simpanan'); ?>
  "nav-link active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('normal'); ?>
  "nav-link"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
    <div class="col-12">
      <div class="card mb-4">
        <div class="card-header pb-0 d-flex">
          <h6 class="flex-grow-1"><?php echo $__env->yieldContent('page'); ?></h6>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
          <div class="table-responsive p-0">
            <form action="<?php echo e(route('simpanan.store')); ?>" method="POST" class="p-4">
              <?php echo csrf_field(); ?>
              <div class=" form-group">
                  <label for="nama">Nama Anggota</label>
                  <select name="nama" id="nama" class="form-select">
                    <option value="">Pilih Anggota</option>
                    <?php $__currentLoopData = $agg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agg->id_member); ?>" data-additional="<?php echo e($agg->nama); ?>"><?php echo e($agg->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
          
              <div class="form-group">
                <label for="jenis">Jenis Simpanan</label>
                <select class="form-control" id="jenis" name="jenis">
                    <option value="">Pilih Jenis Simpanan</option>
                    <option value="pokok">Pokok</option>
                    <option value="wajib">Wajib</option>
                    <option value="sukarela">Sukarela</option>
                </select>
              </div>

              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\SI-Koperasi\resources\views/simpanan/simpanan-pilih.blade.php ENDPATH**/ ?>